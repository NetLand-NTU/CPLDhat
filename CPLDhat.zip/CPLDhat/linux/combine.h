#if !defined COMBINE_H
#define COMBINE_H

#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <sstream>
#include <string.h>

using namespace std;

double*** readfile(char* filename[], int iteration, int C, int nVar)
{
	double ***rate = (double***)calloc(C,sizeof(double**));
	for(int i=0;i<C;i++){
		rate[i] = (double**)calloc(iteration,sizeof(double*));
		for(int j=0;j<iteration;j++)
			rate[i][j] = (double*)calloc(nVar,sizeof(double));
	}


	for(int i=0;i<C;i++){
		ifstream fin(filename[i] , ifstream::in);
		string s;
		getline(fin,s);

		int ii = 0;
		while( getline(fin,s) )
		{
			string d;
			stringstream ss(s);
			int j = 0;
			while(getline(ss,d,' ')){
				rate[i][ii][j]= atof(d.c_str());  
				j++;
			}
			ii++;
		}
		fin.close();
	}

	return rate;
}

void writefile(double ***content, char* filename, int iteration, int C, int nVar,int comb_para=1)//=1 not para  =0 para
{
	double **rate = (double**)calloc(iteration,sizeof(double*));
	for(int j=0;j<iteration;j++)
		rate[j] = (double*)calloc(nVar,sizeof(double));

	ofstream outfile;
	outfile.open(filename);  
	if(outfile.is_open())
	{
		outfile<<iteration<<"\t"<<nVar<<endl;
		for(int i=0;i<C;i++)
			for(int j=0;j<iteration;j++)
				for(int k=0;k<nVar;k++)
					 rate[j][k] += content[i][j][k];

			for(int j=0;j<iteration;j++){
				for(int k=0;k<nVar;k++){
					if(comb_para)	
						rate[j][k] /= C;
					outfile<<rate[j][k]<<" ";
				}
				outfile<<endl;
			}

		outfile.close();
	}
	else
	{
		cout<<"can't open file "<<filename<<endl;
	}


	for(int j=0;j<iteration;j++)
		free(rate[j]);
	free(rate);
}

void combine(string str,int C,int iteration,int nVar, int divid=1)
{
	char** filename = (char**)calloc(C,sizeof(char*));
	for(int i=0;i<C;i++)
		filename[i] = (char*)calloc(200,sizeof(char));
	
	// read k file
	for(int i=0;i<C;i++){
		std::stringstream ss;
		std::string s;
		ss << i;
		s = ss.str();
		strcpy(filename[i], (str+s).c_str());
	}

	char newfilename[20];
	string str1( str, 0, str.size()-1 );
	strcpy(newfilename, str1.c_str());
	double ***content = readfile(filename, iteration, C, nVar);
	writefile(content,newfilename, iteration,C, nVar,divid);

	//delete old file
	//for(int i=0;i<C;i++)
	//	remove(filename[i]);
	

    for(int i=0;i<C;i++){
        for(int j=0;j<iteration;j++)
            free(content[i][j]);
        free(content[i]);
    }
	free(content);

	
	for(int i=0;i<C;i++)
		free(filename[i]);
	free(filename);
	
}

void combine_para(string str,int Cth,int iteration,int nVar,int size,int divid)
{
        char** filename = (char**)calloc(size,sizeof(char*));
        for(int i=0;i<size;i++)
                filename[i] = (char*)calloc(200,sizeof(char));

        // read k file
        for(int i=0;i<size;i++){
        	std::stringstream ss;
                std::string s;
                ss << Cth;
                s = ss.str();
		string temp = str + s;
		temp.append("1111111111",i+1);
                strcpy(filename[i], temp.c_str());
        }
        
	char newfilename[20];
        std::stringstream ss;
	std::string s;
	ss << Cth;
	s = ss.str();
	strcpy(newfilename, (str+s).c_str());
cout<<newfilename<<endl;        
	double ***content = readfile(filename, iteration, size, nVar);
        writefile(content, newfilename, iteration, size, nVar,divid);

        //delete old file
        for(int i=0;i<size;i++)
        	remove(filename[i]);
        
        
        for(int i=0;i<size;i++){
        	for(int j=0;j<iteration;j++)
        	        free(content[i][j]);
                free(content[i]);
        }
        free(content);
        
        
        for(int i=0;i<size;i++)
        	free(filename[i]);
        free(filename);
        
}

#endif
/*
int _tmain(int argc, _TCHAR* argv[])
{
	int C = 5;
	int iteration = 1994;
	int nVar = 4;
	string str =  "E:\\ldsplit\\parameter\\para.txt.";
	combine(str,C,iteration,nVar);
	return 0;
}
*/
