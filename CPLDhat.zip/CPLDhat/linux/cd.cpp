﻿// cd.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
//============================================================================
// Name        : convergence.cpp
// Author      : gj
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C, Ansi-style
//============================================================================

#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
#include <strstream>
#include <string.h>
#include <vector>
#include <cstdlib>
#include <iterator>
#include <iomanip>
#include "Eigen/Dense"
#include "dlib/matrix.h"

using namespace Eigen;
using namespace std;
using namespace dlib;

int** readParafile(char* filename[], int iteration, int C)
{
	int **M = (int**)calloc(C,sizeof(int*));
	for(int i=0;i<C;i++)
		M[i] = (int*)calloc(iteration,sizeof(int));


	for(int i=0;i<C;i++){
		ifstream fin(filename[i] , ifstream::in);
		string s;
		getline(fin,s);

		int jj = 0;
		while( getline(fin,s) )
		{
			string d;
			stringstream ss(s);
			int j = 0;
			while(getline(ss,d,' ')){
				if(j==3) { M[i][jj]= atoi(d.c_str()); jj++; }
				j++;
			}
		}
		fin.close();
	}

	return M;
}

double*** readRatefile(char* filename[], int iteration, int C, int nVar)
{
	double ***rate = (double***)calloc(C,sizeof(double**));
	for(int i=0;i<C;i++){
		rate[i] = (double**)calloc(iteration,sizeof(double*));
		for(int j=0;j<iteration;j++)
			rate[i][j] = (double*)calloc(nVar,sizeof(double));
	}


	for(int i=0;i<C;i++){
		ifstream fin(filename[i] , ifstream::in);
		string s;
		getline(fin,s);

		int ii = 0;
		while( getline(fin,s) )
		{
			string d;
			stringstream ss(s);
			int j = 0;
			while(getline(ss,d,' ')){
				rate[i][ii][j]= atof(d.c_str());  
				j++;
			}
			ii++;
		}
		fin.close();
	}

	return rate;
}

double*** generate_newfiles(double ***RATE, int C, int nVar, int sample_start, int sample_end){
	int length = sample_end - sample_start + 1;
	
	double ***sample_rate = (double***)calloc(C,sizeof(double**));
	for(int i=0;i<C;i++){
		sample_rate[i] = (double**)calloc(length,sizeof(double*));
		for(int j=0;j<length;j++)
			sample_rate[i][j] = (double*)calloc(nVar,sizeof(double));
	}

	for(int ch=0;ch<C;ch++)
		for(int i=sample_start;i<sample_end+1;i++)
			for(int j=0;j<nVar;j++)
				sample_rate[ch][i-sample_start][j] = RATE[ch][i-1][j];

	return sample_rate;

}

int** calc_M(int **M, int C, int sample_start, int sample_end){
	int length = sample_end - sample_start + 1;

	int **sample_M = (int**)calloc(C,sizeof(int*));
	for(int i=0;i<C;i++)
		sample_M[i] = (int*)calloc(length,sizeof(int));

	for(int ch=0;ch<C;ch++)
		for(int i=sample_start;i<sample_end+1;i++)
				sample_M[ch][i-sample_start] = M[ch][i-1];

	return sample_M;
}

int GetUnique(int unique[10], int *tt, int length){

	//get unique vector
		int count = 1;
		unique[0] = tt[0];
		for(int i=1;i<length;i++){
			int flag = 0;
			for(int j=0;j<count;j++)
				if(unique[j] == tt[i]) flag = 1;
			if(!flag){
				unique[count]=tt[i];
				count++;
				flag = 0;
			}
		}

	return count;
}

// Determine whether a contains value k
bool BinarySearch(int *a, int n, int k)
{
    int left = 0 ;
    int right = n - 1 ;
    while (left <= right)
    {
        int mid = (left + right) ;

        if(a[mid] < k)
            left = mid + 1 ;
        if(a[mid] == k)
            return true ;
        else
            right = mid - 1 ;
    }

    return false ;
}

// Compare function for qsort
int compare(const void* a, const void* b)
{
    return *(int*)a - *(int*)b ;
}

int UniqueCommonItem(int unique[10], int **sample_M, int C, int fb)
{
	int ** temp_M = (int**)calloc(C,sizeof(int*));
	for(int i=0;i<C;i++)
		temp_M[i] = (int*)calloc(fb,sizeof(int));

	for(int i=0;i<C;i++)
		for(int j=0;j<fb;j++)
			temp_M[i][j] = sample_M[i][j];

    for(int i=1;i<C;i++)
	    qsort(temp_M[i], fb, sizeof(int), compare) ; // NlogN

	int k = 0; int *tt = (int*)calloc(fb,sizeof(int));
    // for each element in array c, do a binary search in a and b
    for (int i = 0; i < fb; i++)
    {
		int flag = 0;
		for(int j=1;j<C;j++)
	        if(BinarySearch(temp_M[j], fb, temp_M[0][i]))
			    flag++;

		if(flag == 4) tt[k++] = temp_M[0][i];
    }

	k = GetUnique(unique, tt, k);

	for(int i=0;i<C;i++)
		free(temp_M[i]);
	free(temp_M);
	free(tt);
    return k; 
}

double* calc_theta_dian_dian(int C, int T, int nVar, int unique_number, double ***sample_rate, int **sample_M, int * vec_unique){
	double *sum_m = (double*)calloc(nVar,sizeof(double));

	for(int m=0;m<unique_number;m++)
		for(int i=0;i<C;i++)
			for(int k=0;k<T;k++)
				if(sample_M[i][k] == vec_unique[m])
					for(int j=0;j<nVar;j++)
						sum_m[j] += sample_rate[i][k][j];


	for(int i=0;i<nVar;i++)
		sum_m[i] = 1.0/C/T*sum_m[i];

	return sum_m;
}
			
double** calc_theta_dian_m(int C, int T, int nVar, int unique_number, double ***sample_rate, int **sample_M, int *vec_unique)
{
	double **sum_m = (double**)calloc(unique_number,sizeof(double*));
	for(int i=0;i<unique_number;i++)
		sum_m[i] = (double*)calloc(nVar,sizeof(double));

	for(int m=0;m<unique_number;m++)
	{	
		int count = 0;
		for(int i=0;i<C;i++)
			for(int k=0;k<T;k++)
				if(sample_M[i][k] == vec_unique[m])
				{
					count++;
					for(int j=0;j<nVar;j++)
						sum_m[m][j] += sample_rate[i][k][j];
				}

		for(int i=0;i<nVar;i++)
			sum_m[m][i] = 1.0/count*sum_m[m][i];
	}
	
	return sum_m;
}

double** calc_theta_c_dian(int C, int T, int nVar, int unique_number, double ***sample_rate, int **sample_M, int *vec_unique)
{
	double **sum_m = (double**)calloc(C,sizeof(double*));
	for(int i=0;i<C;i++)
		sum_m[i] = (double*)calloc(nVar,sizeof(double));

	for(int m=0;m<unique_number;m++)
		for(int i=0;i<C;i++)
			for(int k=0;k<T;k++)
				if(sample_M[i][k] == vec_unique[m])
					for(int j=0;j<nVar;j++)
						sum_m[i][j] += sample_rate[i][k][j];

	for(int i=0;i<C;i++)
		for(int j=0;j<nVar;j++)
			sum_m[i][j] = 1.0/T*sum_m[i][j];
	
	return sum_m;
}

double*** calc_theta_dian_c_m(int C, int T, int nVar, int unique_number, double ***sample_rate, int **sample_M, int *vec_unique)
{
	double ***sum_m = (double***)calloc(C,sizeof(double**));
	for(int i=0;i<C;i++){
		sum_m[i] = (double**)calloc(unique_number,sizeof(double*));
		for(int j=0;j<unique_number;j++)
			sum_m[i][j] = (double*)calloc(nVar,sizeof(double));
	}


	for(int m=0;m<unique_number;m++)
		for(int i=0;i<C;i++)
		{
			int count = 0; 
			double *temp_sum = (double*)calloc(nVar,sizeof(double));

			for(int k=0;k<T;k++)
				if(sample_M[i][k] == vec_unique[m])
				{
					for(int j=0;j<nVar;j++)
						temp_sum[j] += sample_rate[i][k][j];
					count++;
				}

			for(int f=0;f<nVar;f++)
				sum_m[i][m][f] = 1.0/count*temp_sum[f];

			free(temp_sum);
		}

	return sum_m;
}

double** matrix_multiple(int n, double **x, double **y)
{
	double **result = (double**)calloc(n,sizeof(double*));
	for(int i=0;i<n;i++)
		result[i] = (double*)calloc(n,sizeof(double));

	for(int i=0; i<n; i++)
		for(int j=0; j<n; j++)
		{
			result[i][j] = 0;
			for(int k=0; k<n; k++)
				result[i][j] += x[i][k] * y[k][j];
		}

	return result;
}

double** vector_multiple(int n, double *a, double *b)
{
	double **result = (double**)calloc(n,sizeof(double*));
	for(int i=0;i<n;i++)
		result[i] = (double*)calloc(n,sizeof(double));

	for(int i=0; i<n; i++)
		for(int j=0; j<n; j++)
			result[i][j] = a[i] * b[j];

	return result;
}

// calculate the cofactor of element (row,col)
int GetMinor(double **src, double **dest, int row, int col, int order)
{
    // indicate which col and row is being copied to dest
    int colCount=0,rowCount=0;
 
    for(int i = 0; i < order; i++ )
    {
        if( i != row )
        {
            colCount = 0;
            for(int j = 0; j < order; j++ )
            {
                // when j is not the element
                if( j != col )
                {
                    dest[rowCount][colCount] = src[i][j];
                    colCount++;
                }
            }
            rowCount++;
        }
    }
 
    return 1;
}

// Calculate the determinant recursively.
double CalcDeterminant( double **mat, int order)
{
    // order must be >= 0
    // stop the recursion when matrix is a single element
    if( order == 1 )
        return mat[0][0];
 
    // the determinant value
    double det = 0;
 
    // allocate the cofactor matrix
    double **minor;
    minor = new double*[order-1];
    for(int i=0;i<order-1;i++)
        minor[i] = new double[order-1];
 
    for(int i = 0; i < order; i++ )
    {
        // get minor of element (0,i)
        GetMinor( mat, minor, 0, i , order);
        // the recusion is here!
 
        det += (i%2==1?-1.0:1.0) * mat[0][i] * CalcDeterminant(minor,order-1);
        //det += pow( -1.0, i ) * mat[0][i] * CalcDeterminant( minor,order-1 );
    }
 
    // release memory
    for(int i=0;i<order-1;i++)
        delete [] minor[i];
    delete [] minor;
 
    return det;
}


double** MatrixInversion(double **mat, int nVar)
{
	 double **Y = (double**)calloc(nVar,sizeof(double*));
	 for(int i=0;i<nVar;i++)
		 Y[i] = (double*)calloc(nVar,sizeof(double));

	 matrix<double> A;
	 A.set_size(nVar,nVar);
	 //MatrixXd A(nVar,nVar);

	 for(int i=0;i<nVar;i++)
		for(int j=0;j<nVar;j++)
			A(i,j) = mat[i][j];

    //MatrixXd B = A.inverse();
	matrix<double> B = pinv(A);

	for(int i=0;i<nVar;i++)
		for(int j=0;j<nVar;j++)
			Y[i][j] = B(i,j);

	return Y;
}

//double max_d(MatrixXd N, int n)
double max_d(double *N, int n)
{
	double temp = N[0];
	for(int i=1;i<n;i++)
		if(temp<N[i]) temp = N[i];

	return temp;
}

double eigenvalue_max(double **W, int nVar)
{
	//MatrixXd A(nVar,nVar);
	matrix<double> A;
	A.set_size(nVar,nVar);

	for(int i=0;i<nVar;i++)
		for(int j=0;j<nVar;j++)
			A(i,j) = W[i][j];

	//EigenSolver<MatrixXd> es(A);
	//MatrixXd eigenvalues = es.eigenvalues().real();
	matrix<double> eigenvalues = real_eigenvalues(A);
	double *N = (double*)calloc(nVar,sizeof(double));

	for(int i=0;i<nVar;i++)
		N[i] = eigenvalues(i,0);

	double max_eigen = max_d(N, nVar);

	free(N);
	return max_eigen;
}

double** calc_V(double* theta_dian_dian, int C, int T, int nVar, int unique_number, double ***sample_rate, int **sample_M, int *vec_unique)
{
	double **sum_m = (double**)calloc(nVar,sizeof(double*));
	for(int i=0;i<nVar;i++)
		sum_m[i] = (double*)calloc(nVar,sizeof(double));

	
	for(int m=0;m<unique_number;m++)
		for(int i=0;i<C;i++)
		{
			double *a = (double*)calloc(nVar,sizeof(double));
			for(int k=0;k<T;k++)
				if(sample_M[i][k] == vec_unique[m])
				{
					for(int j=0;j<nVar;j++)
						a[j] = sample_rate[i][k][j] - theta_dian_dian[j];

					double** temp_sum = vector_multiple(nVar, a, a);
					for(int ii=0;ii<nVar;ii++)
						for(int jj=0;jj<nVar;jj++)
							sum_m[ii][jj] += temp_sum[ii][jj];
			
					for(int ii=0;ii<nVar;ii++)
						free(temp_sum[ii]);
					free(temp_sum);
				}

			free(a);
		}
	

	for(int i=0;i<nVar;i++)
		for(int j=0;j<nVar;j++)
			sum_m[i][j] = 1.0/(C*T-1)*sum_m[i][j];
	
	return sum_m;

}

double** calc_w_c(double** theta_c_dian, int C, int T, int nVar, int unique_number, double ***sample_rate, int **sample_M, int *vec_unique)
{
	double **sum_m = (double**)calloc(nVar,sizeof(double*));
	for(int i=0;i<nVar;i++)
		sum_m[i] = (double*)calloc(nVar,sizeof(double));

	for(int m=0;m<unique_number;m++)
		for(int i=0;i<C;i++)
		{
			double *a = (double*)calloc(nVar,sizeof(double));
			for(int k=0;k<T;k++)
				if(sample_M[i][k] == vec_unique[m])
				{
					for(int j=0;j<nVar;j++)
						a[j] = sample_rate[i][k][j] - theta_c_dian[i][j];

					double** temp_sum = vector_multiple(nVar, a, a);
					for(int ii=0;ii<nVar;ii++)
						for(int jj=0;jj<nVar;jj++)
							sum_m[ii][jj] += temp_sum[ii][jj];

			
					for(int ii=0;ii<nVar;ii++)
						free(temp_sum[ii]);
					free(temp_sum);
				}
			free(a);
		}


	for(int i=0;i<nVar;i++)
		for(int j=0;j<nVar;j++)
			sum_m[i][j] = 1.0/(C*T-C)*sum_m[i][j];
	
	return sum_m;

}

double** calc_w_m(double** theta_dian_m, int C, int T, int nVar, int unique_number, double ***sample_rate, int **sample_M, int *vec_unique)
{
	double **sum_m = (double**)calloc(nVar,sizeof(double*));
	for(int i=0;i<nVar;i++)
		sum_m[i] = (double*)calloc(nVar,sizeof(double));

	for(int m=0;m<unique_number;m++)
		for(int i=0;i<C;i++)
		{
			double *a = (double*)calloc(nVar,sizeof(double));
			for(int k=0;k<T;k++)
				if(sample_M[i][k] == vec_unique[m])
				{
					for(int j=0;j<nVar;j++)
						a[j] = sample_rate[i][k][j] - theta_dian_m[m][j];

					double** temp_sum = vector_multiple(nVar, a, a);
					for(int ii=0;ii<nVar;ii++)
						for(int jj=0;jj<nVar;jj++)
							sum_m[ii][jj] += temp_sum[ii][jj];

			
					for(int ii=0;ii<nVar;ii++)
						free(temp_sum[ii]);
					free(temp_sum);
				}
			free(a);
		}


	for(int i=0;i<nVar;i++)
		for(int j=0;j<nVar;j++)
			sum_m[i][j] = 1.0/(C*T-unique_number)*sum_m[i][j];
	
	return sum_m;
}

double** calc_w_m_c(double*** theta_dian_c_m, int C, int T, int nVar, int unique_number, double ***sample_rate, int **sample_M, int *vec_unique)
{
	double **sum_m = (double**)calloc(nVar,sizeof(double*));
	for(int i=0;i<nVar;i++)
		sum_m[i] = (double*)calloc(nVar,sizeof(double));

	for(int m=0;m<unique_number;m++)
		for(int i=0;i<C;i++)
		{
			double *a = (double*)calloc(nVar,sizeof(double));
			for(int k=0;k<T;k++)
				if(sample_M[i][k] == vec_unique[m])
				{
					for(int j=0;j<nVar;j++)
						a[j] = sample_rate[i][k][j] - theta_dian_c_m[i][m][j];

					double** temp_sum = vector_multiple(nVar, a, a);
					for(int ii=0;ii<nVar;ii++)
						for(int jj=0;jj<nVar;jj++)
							sum_m[ii][jj] += temp_sum[ii][jj];

			
					for(int ii=0;ii<nVar;ii++)
						free(temp_sum[ii]);
					free(temp_sum);
				}
			free(a);
		}


	for(int i=0;i<nVar;i++)
		for(int j=0;j<nVar;j++)
			sum_m[i][j] = 1.0/(C*T-C*unique_number)*sum_m[i][j];
	
	return sum_m;

}



void rjMCMC_convergence(int C, int T, int nVar)
{
	char** filename = (char**)calloc(C,sizeof(char*));
	for(int i=0;i<C;i++)
		filename[i] = (char*)calloc(200,sizeof(char));
	
	// read k file
	for(int i=0;i<C;i++){
		string str1 = "E:\\ldsplit\\parameter\\11000000-100000-10000\\para.txt.";
		strstream ss;
		string s;
		ss << i;
		ss >> s;
		strcpy(filename[i], (str1+s).c_str());
	}
	int **M = readParafile(filename, T, C);

	// read rate file
	for(int i=0;i<C;i++){
		string str1 = "E:\\ldsplit\\parameter\\11000000-100000-10000\\rates.txt.";
		strstream ss;
		string s;
		ss << i;
		ss >> s;
		strcpy(filename[i], (str1+s).c_str());
	}
	double ***RATE = readRatefile(filename, T, C, nVar);

	// for loop
	int b = (int)(T/20);
	int q = 10;

	double* MPSRF1 = (double*)calloc(q,sizeof(double));
	double* MPSRF2 = (double*)calloc(q,sizeof(double));
	double* PSRF1 = (double*)calloc(q,sizeof(double));
	double* PSRF2 = (double*)calloc(q,sizeof(double));


	for(int f=1;f<q+1;f++){
		int sample_start = b*f + 1;
		int sample_end = 2*b*f;

		double ***sample_rate = generate_newfiles(RATE, C, nVar, sample_start, sample_end);
		int **sample_M = calc_M(M, C, sample_start, sample_end);

		int vec_unique[10];
		int unique_number = UniqueCommonItem(vec_unique, sample_M, C, f*b);
		
		double* theta_dian_dian = calc_theta_dian_dian(C, f*b, nVar, unique_number, sample_rate, sample_M, vec_unique); //nVar
		double** theta_dian_m = calc_theta_dian_m(C, f*b, nVar, unique_number, sample_rate, sample_M, vec_unique);
		double** theta_c_dian = calc_theta_c_dian(C, f*b, nVar, unique_number, sample_rate, sample_M, vec_unique);
		double*** theta_dian_c_m = calc_theta_dian_c_m(C, f*b, nVar, unique_number, sample_rate, sample_M, vec_unique);
		
		double** V = calc_V(theta_dian_dian, C, b*f, nVar, unique_number, sample_rate, sample_M, vec_unique);
		double** Wc = calc_w_c(theta_c_dian, C, b*f, nVar, unique_number, sample_rate, sample_M, vec_unique);
		double** Wm = calc_w_m(theta_dian_m, C, b*f, nVar, unique_number, sample_rate, sample_M, vec_unique);
		double** WmWc = calc_w_m_c(theta_dian_c_m, C, b*f, nVar, unique_number, sample_rate, sample_M, vec_unique);

		double** Y = matrix_multiple(nVar, MatrixInversion(Wc, nVar), V);
		MPSRF1[f-1] = eigenvalue_max(Y, nVar);

		Y = matrix_multiple(nVar, MatrixInversion(WmWc, nVar), Wm);
		MPSRF2[f-1] = eigenvalue_max(Y, nVar);
		
		PSRF1[f-1] = eigenvalue_max(V, nVar)/eigenvalue_max(Wc, nVar);
		PSRF2[f-1] = eigenvalue_max(Wm, nVar)/eigenvalue_max(WmWc, nVar);


		//lease space
		for(int i=0;i<C;i++){
			for(int j=0;j<f*b;j++)
				free(sample_rate[i][j]);
			free(sample_rate[i]);
		}
		free(sample_rate);

		for(int i=0;i<C;i++)
			free(sample_M[i]);
		free(sample_M);

		free(theta_dian_dian);

		for(int i=0;i<unique_number;i++)
			free(theta_dian_m[i]);
		free(theta_dian_m);

		for(int i=0;i<C;i++)
			free(theta_c_dian[i]);
		free(theta_c_dian);

		for(int i=0;i<C;i++){
			for(int j=0;j<unique_number;j++)
				free(theta_dian_c_m[i][j]);
			free(theta_dian_c_m[i]);
		}
		free(theta_dian_c_m);

		for(int i=0;i<nVar;i++){
			free(V[i]);
			free(Wc[i]);
			free(Wm[i]);
			free(WmWc[i]);
			free(Y[i]);
		}
		free(V);free(Wc);free(Wm);free(WmWc);free(Y);


	}

	for(int i=0;i<q;i++)
		cout<<MPSRF1[i]<<endl;
	cout<<endl;
	for(int i=0;i<q;i++)
		cout<<MPSRF2[i]<<endl;
	cout<<endl;
	for(int i=0;i<q;i++)
		cout<<PSRF1[i]<<endl;
	cout<<endl;
	for(int i=0;i<q;i++)
		cout<<PSRF2[i]<<endl;


	// release space
	for(int i=0;i<C;i++)
		free(filename[i]);
	free(filename);

	for(int i=0;i<C;i++)
		free(M[i]);
	free(M);

	for(int i=0;i<C;i++){		
		for(int j=0;j<T;j++)
			free(RATE[i][j]);
		free(RATE[i]);
	}
	free(RATE);

	free(MPSRF1);
	free(MPSRF2);
	free(PSRF1);
	free(PSRF2);


}


int main(int argc, char* argv[])
{
	int C = 5; //chain number
	int T = 1091; //iteration
	int nVar = 99;

	rjMCMC_convergence(C,T,nVar);

	

	return 0;
}

